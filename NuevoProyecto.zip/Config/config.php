<?php

return array(	// =>> PARÁMETROS  DE  LA  APLICACIÓN.
				'app_name'			=> 'DecPHP Framework',
				'app_author'		=> 'Edgard Decena',
				'app_email'			=> 'edecena@gmail.com',
				'app_version'		=> '1.0.0',
				'author_web'		=> 'http://www.gnusistemas.com/',
				'year_develop'		=> date('Y'),


				// =>> DIRECTORIOS  DEL  FRAMEWORK.
				'cache_folder'		=> 'Cache',
				'classes_folder'	=> 'Classes',	// NO Cambiar.
				'config_folder'		=> 'Config',	// NO Cambiar.
				'controllers_folder'=> 'Controllers',
				'data_folder'		=> 'Data',		// NO Cambiar.
				'libs_folder'		=> 'Libs',
				'models_folder'		=> 'Models',
				'templates_folder'	=> 'Templates',
				'views_folder'		=> 'Views',
				'widgets_folder'	=> 'Widgets',


				// =>> PARÁMETROS  DEL  FRAMEWORK.
				'debug_mode'        => true,
				'default_controller'=> 'Inicio',
				'template' 			=> 'DecPHP',
				'hash_key'			=> '*****', 	// NO Cambiar.
				'hash_algorithm'	=> 'sha1',
				'set_locale'		=> 'es_VE',
				'time_zone'			=> 'America/Caracas',
				'session_time'		=> 0,	// Tiempo de session en minutos. Cero = Tiempo indefinido.
				'access_levels'		=> array(	'admin'		=> 1,	// Acceso administrador.
												'usuario' 	=> 2,
												'invitado'	=> 3
											),
				'database_config'	=> array(	'engine'   => 'sqlite:/var/www/NuevoProyecto/Data/database.db',
												'host'     => '',
												'port'     => '',
												'user'     => '',
												'pass'     => '',
												'database' => ''
											)
				);