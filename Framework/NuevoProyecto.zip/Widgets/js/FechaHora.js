function hora()
{
	var fecha   = new Date()
	var hora    = fecha.getHours()

	ampm = " am."
	
	if (hora > 12)
	{
	    hora -= 12;
	    ampm = " pm."
	}
	else if (hora === 0)
	{
	   hora = 12;
	}

	var minuto  = fecha.getMinutes()
	var segundo = fecha.getSeconds()

	if (hora < 10) {hora       = "0" + hora}
	if (minuto < 10) {minuto   = "0" + minuto}
	if (segundo < 10) {segundo = "0" + segundo}
	
	var horita = hora + ":" + minuto + ":" + segundo + ampm

	document.getElementById('hora').firstChild.nodeValue = horita

	tiempo = setTimeout('hora()',1000)
}

function inicio()
{
	document.write('<span id="hora">')
	document.write ('000000</span>')
	hora()
}