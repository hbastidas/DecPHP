<?php

final class controllerProductos extends Controller
{

	public function __construct()
	{
		parent::__construct();
	}


	public function index()
	{
		$Productos = Model::get('Productos');

		View::$data = $Productos->buscar();

		View::render('Productos.Productos');
	}


	public function agregar()
	{
		View::render('Productos.AgregarProducto');
	}


	public function agregar_post()
	{
		if (isset($_POST['agregar']))
		{
			extract($_POST);

			$Productos = Model::get('Productos');
			
			$precio       = trim($precio);
			
			$precio       = empty($precio) ? 0 : $precio;
			
			$precio       = is_numeric($precio) ? (float) $precio : false;

			$nom_producto = trim($nom_producto);

			if ($precio === false)
			{
				$this->_error('Error al Agregar Producto.', 'Debe proveer un precio numérico.');
				exit;
			}

			if (!empty($nom_producto))
			{
				if (count($Productos->buscarProducto($nom_producto)) === 0)
				{
					$Productos->agregar($nom_producto, $precio);

					if ($Productos->error())
					{
						$this->_error('Error al Agregar Producto.', 'La petición de agregar producto no ha podido realizarse.');
					}
					else
					{
						$this->_mensaje('El Producto fue agregado con éxito.', 'La petición de agregar producto se realizó exitosamente.');
					}
				}
				else
				{
					$this->_error('Error al Agregar Producto.', 'El nombre de producto \''.$nom_producto.'\' ya existe en la base de datos y no puede ser duplicado.');
				}
			}
			else
			{
				$this->_error('Error al agregar Producto.', 'Debe de proveer un nombre de producto válido.');
			}
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function buscar()
	{

		View::render('Productos.BuscarProducto');
	}


	public function buscar_post()
	{
		if (isset($_POST['buscar']))
		{
			extract($_POST);

			// VALIDACIONES
			
			$id_producto  = trim($id_producto);
			
			$id_producto  = (int) $id_producto;
			
			$id_producto  = is_integer($id_producto) ? $id_producto : false;
			
			$precio       = trim($precio);

			$precio       = empty($precio) ? 0 : $precio;
			
			$precio       = is_numeric($precio) ? (float) $precio : false;
			
			$nom_producto = trim($nom_producto);
			
			$nom_producto = !empty($nom_producto) ? $nom_producto : false;


			$sql = 'SELECT * FROM Producto WHERE ';


			if (!$id_producto and !$nom_producto and !$precio)
			{
				$this->_error('Error al Buscar Producto.', 'Debe proveer al menos un dato válido para la búsqueda de Producto.');
				exit;
			}

			if ($id_producto) $sql  .= '(id_producto = '.$id_producto.') OR ';
			
			if ($nom_producto) $sql .= '(nom_producto LIKE \'%'.$nom_producto.'%\') OR ';
			
			if ($precio) $sql       .= '(precio '.$operador.' '.$precio.')';

			$sql = trim($sql, ' OR ');
			$sql = trim($sql, ' OR ');
			$sql = trim($sql, ' WHERE ');
			$sql .= ';';

			$Resultado = new ActiveRecord($sql);

			View::$data = $Resultado->dataSet();

			View::render('Productos.ResultadoBuscar');

		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function editar($id_producto = null)
	{
		if ($id_producto)
		{
			$Productos = Model::get('Productos');

			View::$data = $Productos->buscar($id_producto);

			View::render('Productos.EditarProducto');
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function editar_post()
	{
		if (isset($_POST['editar']))
		{
			extract($_POST);

			$Productos    = Model::get('Productos');
			
			$precio       = trim($precio);
			
			$precio       = empty($precio) ? 0 : $precio;
			
			$precio       = is_numeric($precio) ? (float) $precio : false;
			
			$nom_producto = trim($nom_producto);
			

			if ($precio === false)
			{
				$this->_error('Error al Editar Producto.', 'Debe proveer un precio numérico.');
				exit;
			}

			if (!empty($nom_producto))
			{
				if (count($Productos->buscarProducto($nom_producto)) === 0 xor ($nom_producto === $old_nom_producto))
				{
					$Productos->editar($id_producto, $nom_producto, $precio);

					if ($Productos->error())
					{
						$this->_error('Error al Editar Producto.', 'La petición de editar producto no ha podido realizarse.');
					}
					else
					{
						$this->_mensaje('El Producto fue actualizado con éxito.', 'La petición de actualizar producto se realizó exitosamente.');
					}
				}
				else
				{
					$this->_error('Error al Editar Producto.', 'El nombre de producto \''.$nom_producto.'\' ya existe en la base de datos y no puede ser duplicado.');
				}
			}
			else
			{
				$this->_error('Error al Editar Producto.', 'Debe de proveer un nombre de producto válido.');
			}
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function eliminar($id_producto = null)
	{
		if (isset($id_producto))
		{
			$Productos = Model::get('Productos');

			View::$data = $Productos->buscar($id_producto);

			View::render('Productos.EliminarProducto');
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function eliminar_post()
	{
		if (isset($_POST['eliminar']))
		{
			extract ($_POST);

			$Productos = Model::get('Productos');

			$Productos->eliminar($id_producto);

			if ($Productos->error())
			{
				$this->_error('Error al Eliminar Producto.', 'La petición de eliminar producto no ha podido realizarse.');
			}
			else
			{
				$this->_mensaje('El Producto fue Eliminado con éxito.', 'La petición de eliminar producto se realizó exitosamente.');
			}

		}
		else
		{
			Router::redirect('/productos');
		}
	}


	public function error()
	{
		if (isset($_POST['titulo']))
		{
			View::$data = $_POST;

			View::render('Productos.Error');
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	private function _error($titulo = null, $mensaje = null)
	{
		$arreglo = compact('titulo', 'mensaje');

		Router::redirect('/productos/error', 'POST', $arreglo);
	}


	public function mensaje()
	{
		if (isset($_POST['titulo']))
		{
			View::$data = $_POST;

			View::render('Productos.Mensaje');
		}
		else
		{
			Router::redirect('/productos');
		}
	}


	private function _mensaje($titulo = null, $mensaje = null)
	{
		$arreglo = compact('titulo', 'mensaje');

		Router::redirect('/productos/mensaje', 'POST', $arreglo);
	}

}