<?php

final class modelProductos extends Model
{

	public function __construct()
	{
		parent::__construct();
	}


	public function agregar($nom_producto = null, $precio = null)
	{
		$sql = 'INSERT INTO Producto (nom_producto, precio) VALUES (:nom_producto, :precio);';
		return $this->execute($sql, array(':nom_producto' => $nom_producto, ':precio' => $precio));
	}


	public function buscar($id_producto = null)
	{
		if ($id_producto)
		{
			$sql = 'SELECT * FROM Producto WHERE id_producto = :id_producto;';
			return $this->execute($sql, array(':id_producto' => $id_producto));
		}
		else
		{
			$sql = 'SELECT * FROM Producto;';
			return $this->execute($sql);
		}
	}


	public function buscarProducto($nom_producto = null)
	{
		if ($nom_producto)
		{
			$sql = 'SELECT * FROM Producto WHERE nom_producto = :nom_producto;';
			return $this->execute($sql, array(':nom_producto' => $nom_producto));
		}
		else
		{
			return 0;
		}
	}


	public function editar($id_producto = null, $nom_producto = null, $precio = null)
	{
		$sql = 'UPDATE Producto SET nom_producto = :nom_producto, precio = :precio WHERE id_producto = :id_producto;';
		return $this->execute($sql, array(':nom_producto' => $nom_producto, ':precio' => $precio, ':id_producto' => $id_producto));
	}


	public function eliminar($id_producto = null)
	{
		$sql = 'DELETE FROM Producto WHERE id_producto = :id_producto;';
		return $this->execute($sql, array(':id_producto' => $id_producto));
	}

}